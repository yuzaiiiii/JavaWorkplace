package com.sky.controller.user;

import com.sky.entity.Favorite;
import com.sky.result.Result;
import com.sky.service.FavoriteService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController("userFavoriteController")
@RequestMapping("/user/favorite")
@Slf4j
@Api(tags = "C端-收藏接口")
public class FavoriteController {

    @Autowired
    private FavoriteService favoriteService;

    /**
     * 查询用户的收藏列表
     * @return
     */
    @GetMapping("/list")
    @ApiOperation("查询用户的收藏列表")
    public Result<List<Favorite>> list() {
        //从当前上下文中获取用户id
        Long userId = com.sky.context.BaseContext.getCurrentId();
        List<Favorite> favoriteList = favoriteService.listByUserId(userId);
        return Result.success(favoriteList);
    }

    /**
     * 收藏菜品
     * @param dishId
     * @return
     */
    @PostMapping("/dish")
    @ApiOperation("收藏菜品")
    public Result<String> addDishFavorite(Long dishId) {
        //从当前上下文中获取用户id
        Long userId = com.sky.context.BaseContext.getCurrentId();
        favoriteService.addDishFavorite(userId, dishId);
        return Result.success("收藏成功");
    }

    /**
     * 收藏套餐
     * @param setmealId
     * @return
     */
    @PostMapping("/setmeal")
    @ApiOperation("收藏套餐")
    public Result<String> addSetmealFavorite(Long setmealId) {
        //从当前上下文中获取用户id
        Long userId = com.sky.context.BaseContext.getCurrentId();
        favoriteService.addSetmealFavorite(userId, setmealId);
        return Result.success("收藏成功");
    }

    /**
     * 取消收藏菜品
     * @param dishId
     * @return
     */
    @PostMapping("/dish/remove")
    @ApiOperation("取消收藏菜品")
    public Result<String> removeDishFavorite(Long dishId) {
        //从当前上下文中获取用户id
        Long userId = com.sky.context.BaseContext.getCurrentId();
        favoriteService.removeDishFavorite(userId, dishId);
        return Result.success("取消收藏成功");
    }

    /**
     * 取消收藏套餐
     * @param setmealId
     * @return
     */
    @PostMapping("/setmeal/remove")
    @ApiOperation("取消收藏套餐")
    public Result<String> removeSetmealFavorite(Long setmealId) {
        //从当前上下文中获取用户id
        Long userId = com.sky.context.BaseContext.getCurrentId();
        favoriteService.removeSetmealFavorite(userId, setmealId);
        return Result.success("取消收藏成功");
    }
}
