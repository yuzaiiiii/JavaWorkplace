package com.sky.service;

import com.sky.entity.Favorite;
import java.util.List;

public interface FavoriteService {

    /**
     * 查询用户的收藏列表
     * @param userId
     * @return
     */
    List<Favorite> listByUserId(Long userId);

    /**
     * 收藏菜品
     * @param userId
     * @param dishId
     */
    void addDishFavorite(Long userId, Long dishId);

    /**
     * 收藏套餐
     * @param userId
     * @param setmealId
     */
    void addSetmealFavorite(Long userId, Long setmealId);

    /**
     * 取消收藏菜品
     * @param userId
     * @param dishId
     */
    void removeDishFavorite(Long userId, Long dishId);

    /**
     * 取消收藏套餐
     * @param userId
     * @param setmealId
     */
    void removeSetmealFavorite(Long userId, Long setmealId);
}
