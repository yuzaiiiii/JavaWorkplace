package com.sky.service.impl;

import com.sky.entity.Favorite;
import com.sky.mapper.FavoriteMapper;
import com.sky.service.FavoriteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class FavoriteServiceImpl implements FavoriteService {

    @Autowired
    private FavoriteMapper favoriteMapper;

    @Override
    public List<Favorite> listByUserId(Long userId) {
        return favoriteMapper.getByUserId(userId);
    }

    @Override
    public void addDishFavorite(Long userId, Long dishId) {
        //先查询是否已经收藏
        Favorite favorite = favoriteMapper.getByUserIdAndDishId(userId, dishId);
        if (favorite == null) {
            //如果没有收藏，则添加
            favorite = new Favorite();
            favorite.setUserId(userId);
            favorite.setDishId(dishId);
            favorite.setCreateTime(LocalDateTime.now());
            favoriteMapper.insert(favorite);
        }
    }

    @Override
    public void addSetmealFavorite(Long userId, Long setmealId) {
        //先查询是否已经收藏
        Favorite favorite = favoriteMapper.getByUserIdAndSetmealId(userId, setmealId);
        if (favorite == null) {
            //如果没有收藏，则添加
            favorite = new Favorite();
            favorite.setUserId(userId);
            favorite.setSetmealId(setmealId);
            favorite.setCreateTime(LocalDateTime.now());
            favoriteMapper.insert(favorite);
        }
    }

    @Override
    public void removeDishFavorite(Long userId, Long dishId) {
        favoriteMapper.deleteByUserIdAndDishId(userId, dishId);
    }

    @Override
    public void removeSetmealFavorite(Long userId, Long setmealId) {
        favoriteMapper.deleteByUserIdAndSetmealId(userId, setmealId);
    }
}
