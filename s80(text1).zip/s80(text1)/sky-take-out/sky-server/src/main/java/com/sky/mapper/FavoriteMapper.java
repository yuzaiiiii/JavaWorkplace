package com.sky.mapper;

import com.sky.entity.Favorite;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import java.util.List;

@Mapper
public interface FavoriteMapper {

    /**
     * 根据用户id查询收藏的菜品和套餐
     * @param userId
     * @return
     */
    @Select("select * from favorite where user_id = #{userId}")
    List<Favorite> getByUserId(Long userId);

    /**
     * 根据用户id和菜品id查询收藏记录
     * @param userId
     * @param dishId
     * @return
     */
    @Select("select * from favorite where user_id = #{userId} and dish_id = #{dishId}")
    Favorite getByUserIdAndDishId(Long userId, Long dishId);

    /**
     * 根据用户id和套餐id查询收藏记录
     * @param userId
     * @param setmealId
     * @return
     */
    @Select("select * from favorite where user_id = #{userId} and setmeal_id = #{setmealId}")
    Favorite getByUserIdAndSetmealId(Long userId, Long setmealId);

    /**
     * 插入收藏记录
     * @param favorite
     */
    @Insert("insert into favorite (user_id, dish_id, setmeal_id, create_time) values (#{userId}, #{dishId}, #{setmealId}, #{createTime})")
    void insert(Favorite favorite);

    /**
     * 根据用户id和菜品id删除收藏记录
     * @param userId
     * @param dishId
     */
    @Delete("delete from favorite where user_id = #{userId} and dish_id = #{dishId}")
    void deleteByUserIdAndDishId(Long userId, Long dishId);

    /**
     * 根据用户id和套餐id删除收藏记录
     * @param userId
     * @param setmealId
     */
    @Delete("delete from favorite where user_id = #{userId} and setmeal_id = #{setmealId}")
    void deleteByUserIdAndSetmealId(Long userId, Long setmealId);
}
