# 收藏功能接口测试数据

## 1. 查询用户的收藏列表
- **接口地址**: `GET /user/favorite/list`
- **请求头**: `Authorization: Bearer {token}`
- **响应示例**:
```json
{
  "code": 1,
  "msg": "成功",
  "data": [
    {
      "id": 1,
      "userId": 123,
      "dishId": 456,
      "setmealId": null,
      "createTime": "2023-01-01T12:00:00"
    },
    {
      "id": 2,
      "userId": 123,
      "dishId": null,
      "setmealId": 789,
      "createTime": "2023-01-02T12:00:00"
    }
  ]
}
```

## 2. 收藏菜品
- **接口地址**: `POST /user/favorite/dish`
- **请求头**: `Authorization: Bearer {token}`
- **请求参数**: `dishId=456`
- **响应示例**:
```json
{
  "code": 1,
  "msg": "收藏成功"
}
```

## 3. 收藏套餐
- **接口地址**: `POST /user/favorite/setmeal`
- **请求头**: `Authorization: Bearer {token}`
- **请求参数**: `setmealId=789`
- **响应示例**:
```json
{
  "code": 1,
  "msg": "收藏成功"
}
```

## 4. 取消收藏菜品
- **接口地址**: `POST /user/favorite/dish/remove`
- **请求头**: `Authorization: Bearer {token}`
- **请求参数**: `dishId=456`
- **响应示例**:
```json
{
  "code": 1,
  "msg": "取消收藏成功"
}
```

## 5. 取消收藏套餐
- **接口地址**: `POST /user/favorite/setmeal/remove`
- **请求头**: `Authorization: Bearer {token}`
- **请求参数**: `setmealId=789`
- **响应示例**:
```json
{
  "code": 1,
  "msg": "取消收藏成功"
}
```

## 测试说明
- `{token}` 为用户登录后获取的JWT令牌
- `userId` 为当前登录用户的ID，从JWT令牌中解析得到
- `dishId` 和 `setmealId` 需要替换为实际存在的菜品ID和套餐ID
