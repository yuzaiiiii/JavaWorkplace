-- 创建收藏表
CREATE TABLE favorite (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '主键',
    user_id BIGINT NOT NULL COMMENT '用户id',
    dish_id BIGINT COMMENT '菜品id',
    setmeal_id BIGINT COMMENT '套餐id',
    create_time DATETIME NOT NULL COMMENT '创建时间',
    UNIQUE KEY uk_user_dish (user_id, dish_id),
    UNIQUE KEY uk_user_setmeal (user_id, setmeal_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='收藏表';
