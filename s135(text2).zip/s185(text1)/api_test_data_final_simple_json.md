# 外卖小程序购买历史功能接口测试数据

## 1. 查询购买历史列表
- **接口地址**: `/user/purchase-history/page`
- **请求方式**: GET
- **请求头**: `token: user_token`
- **请求参数**:
  ```json
  {
    "page": 1,
    "pageSize": 10,
    "status": 1
  }
  ```
- **响应示例**:
  ```json
  {
    "code": 1,
    "msg": "操作成功",
    "data": {
      "records": [
        {
          "id": 1,
          "userId": 1,
          "orderId": 1001,
          "dishId": 201,
          "setmealId": null,
          "type": 1,
          "quantity": 2,
          "orderTime": "2024-05-20 12:30:45",
          "status": 1
        }
      ],
      "total": 1,
      "page": 1,
      "pageSize": 10
    }
  }
  ```

## 2. 取消订单
- **接口地址**: `/user/purchase-history/cancel/{orderId}`
- **请求方式**: POST
- **请求头**: `token: user_token`
- **响应示例**:
  ```json
  {
    "code": 1,
    "msg": "取消订单成功"
  }
  ```

## 3. 查询订单详情
- **接口地址**: `/user/purchase-history/detail/{orderId}`
- **请求方式**: GET
- **请求头**: `token: user_token`
- **响应示例**:
  ```json
  {
    "code": 1,
    "msg": "操作成功",
    "data": {
      "orderId": 1001,
      "orderTime": "2024-05-20 12:30:45",
      "totalAmount": 59.9,
      "status": 1,
      "items": [
        {
          "id": 201,
          "name": "香辣鸡腿堡",
          "image": "/images/hamburger.jpg",
          "price": 29.95,
          "quantity": 2,
          "type": 1
        }
      ]
    }
  }
  ```