package com.sky.mapper;

import com.sky.entity.UserPurchaseHistory;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UserPurchaseHistoryMapper {

    /**
     * 批量插入用户购买历史
     * @param userPurchaseHistoryList
     */
    void insertBatch(List<UserPurchaseHistory> userPurchaseHistoryList);

    /**
     * 根据用户id和订单状态查询购买历史
     * @param userId
     * @param status
     * @return
     */
    List<UserPurchaseHistory> listByUserIdAndStatus(Long userId, Integer status);

    /**
     * 根据订单id查询购买历史
     * @param orderId
     * @return
     */
    @Select("select * from user_purchase_history where order_id = #{orderId}")
    List<UserPurchaseHistory> getByOrderId(Long orderId);

    /**
     * 根据订单id更新购买历史的订单状态
     * @param orderId
     * @param status
     */
    void updateStatusByOrderId(Long orderId, Integer status);
}