package com.sky.service;

import com.sky.entity.UserPurchaseHistory;
import com.sky.result.PageResult;

import java.util.List;

public interface UserPurchaseHistoryService {

    /**
     * 记录用户购买历史
     * @param orderId
     */
    void recordPurchaseHistory(Long orderId);

    /**
     * 根据用户id和订单状态查询购买历史
     * @param userId
     * @param status
     * @return
     */
    List<UserPurchaseHistory> listByUserIdAndStatus(Long userId, Integer status);

    /**
     * 根据订单id更新购买历史的订单状态
     * @param orderId
     * @param status
     */
    void updateStatusByOrderId(Long orderId, Integer status);
}