package com.sky.service.impl;

import com.sky.entity.OrderDetail;
import com.sky.entity.Orders;
import com.sky.entity.UserPurchaseHistory;
import com.sky.mapper.OrderDetailMapper;
import com.sky.mapper.OrderMapper;
import com.sky.mapper.UserPurchaseHistoryMapper;
import com.sky.service.UserPurchaseHistoryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class UserPurchaseHistoryServiceImpl implements UserPurchaseHistoryService {

    @Autowired
    private UserPurchaseHistoryMapper userPurchaseHistoryMapper;

    @Autowired
    private OrderMapper orderMapper;

    @Autowired
    private OrderDetailMapper orderDetailMapper;

    /**
     * 记录用户购买历史
     * @param orderId
     */
    @Override
    @Transactional
    public void recordPurchaseHistory(Long orderId) {
        // 根据订单id查询订单信息
        Orders orders = orderMapper.getById(orderId);
        if (orders == null) {
            return;
        }

        // 根据订单id查询订单明细
        List<OrderDetail> orderDetailList = orderDetailMapper.getByOrderId(orderId);
        if (orderDetailList == null || orderDetailList.size() == 0) {
            return;
        }

        // 封装用户购买历史
        List<UserPurchaseHistory> userPurchaseHistoryList = new ArrayList<>();
        for (OrderDetail orderDetail : orderDetailList) {
            UserPurchaseHistory userPurchaseHistory = UserPurchaseHistory.builder()
                    .userId(orders.getUserId())
                    .orderId(orderId)
                    .dishId(orderDetail.getDishId())
                    .setmealId(orderDetail.getSetmealId())
                    .type(orderDetail.getDishId() != null ? 1 : 2) // 1表示菜品，2表示套餐
                    .number(orderDetail.getNumber())
                    .orderTime(orders.getOrderTime())
                    .status(orders.getStatus())
                    .name(orderDetail.getName())
                    .image(orderDetail.getImage())
                    .amount(orderDetail.getAmount())
                    .orderNumber(orders.getNumber())
                    .build();
            userPurchaseHistoryList.add(userPurchaseHistory);
        }

        // 批量插入用户购买历史
        userPurchaseHistoryMapper.insertBatch(userPurchaseHistoryList);
    }

    /**
     * 根据用户id和订单状态查询购买历史
     * @param userId
     * @param status
     * @return
     */
    @Override
    public List<UserPurchaseHistory> listByUserIdAndStatus(Long userId, Integer status) {
        return userPurchaseHistoryMapper.listByUserIdAndStatus(userId, status);
    }

    /**
     * 根据订单id更新购买历史的订单状态
     * @param orderId
     * @param status
     */
    @Override
    public void updateStatusByOrderId(Long orderId, Integer status) {
        userPurchaseHistoryMapper.updateStatusByOrderId(orderId, status);
    }
}