package com.sky.controller.user;

import com.sky.context.BaseContext;
import com.sky.entity.UserPurchaseHistory;
import com.sky.result.Result;
import com.sky.service.UserPurchaseHistoryService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController("userUserPurchaseHistoryController")
@RequestMapping("/user/purchase-history")
@Api(tags = "用户端购买历史相关接口")
@Slf4j
public class UserPurchaseHistoryController {

    @Autowired
    private UserPurchaseHistoryService userPurchaseHistoryService;

    /**
     * 查询用户购买历史
     * @param status 订单状态 1待付款 2待接单 3已接单 4派送中 5已完成 6已取消
     * @return
     */
    @GetMapping
    @ApiOperation("查询用户购买历史")
    public Result<List<UserPurchaseHistory>> list(@RequestParam(required = false) Integer status) {
        Long userId = BaseContext.getCurrentId();
        List<UserPurchaseHistory> userPurchaseHistoryList = userPurchaseHistoryService.listByUserIdAndStatus(userId, status);
        return Result.success(userPurchaseHistoryList);
    }
}