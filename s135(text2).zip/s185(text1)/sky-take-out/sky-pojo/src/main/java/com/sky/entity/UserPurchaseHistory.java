package com.sky.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 用户购买历史
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserPurchaseHistory implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    //用户id
    private Long userId;

    //订单id
    private Long orderId;

    //菜品id
    private Long dishId;

    //套餐id
    private Long setmealId;

    //商品类型（菜品、套餐）
    private Integer type;

    //购买数量
    private Integer number;

    //下单时间
    private LocalDateTime orderTime;

    //订单状态（1待付款 2待接单 3已接单 4派送中 5已完成 6已取消）
    private Integer status;

    //商品名称
    private String name;

    //商品图片
    private String image;

    //商品单价
    private BigDecimal amount;

    //订单编号
    private String orderNumber;
}