CREATE TABLE `user_purchase_history` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` bigint NOT NULL COMMENT '用户id',
  `order_id` bigint NOT NULL COMMENT '订单id',
  `dish_id` bigint DEFAULT NULL COMMENT '菜品id',
  `setmeal_id` bigint DEFAULT NULL COMMENT '套餐id',
  `type` int NOT NULL COMMENT '商品类型（1菜品、2套餐）',
  `number` int NOT NULL COMMENT '购买数量',
  `order_time` datetime NOT NULL COMMENT '下单时间',
  `status` int NOT NULL COMMENT '订单状态（1待付款 2待接单 3已接单 4派送中 5已完成 6已取消）',
  `name` varchar(255) NOT NULL COMMENT '商品名称',
  `image` varchar(255) DEFAULT NULL COMMENT '商品图片',
  `amount` decimal(10,2) NOT NULL COMMENT '商品单价',
  `order_number` varchar(255) NOT NULL COMMENT '订单编号',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户购买历史表';