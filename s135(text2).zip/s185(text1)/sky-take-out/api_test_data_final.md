# 购买历史功能接口测试数据

## 1. 用户下单接口
- **接口**：`POST /user/order/submit`
- **请求头**：`Authorization: Bearer <用户token>`
- **请求体**：
```json
{
  "addressBookId": 1,
  "payMethod": 1,
  "remark": "测试订单",
  "amount": 100.00
}
```
- **响应示例**：
```json
{
  "code": 1,
  "msg": "成功",
  "data": {
    "id": 1001,
    "orderTime": "2025-12-24 12:00:00",
    "orderNumber": "1234567890",
    "orderAmount": 100.00
  }
}
```

## 2. 查询购买历史接口
- **接口**：`GET /user/purchase-history`
- **请求头**：`Authorization: Bearer <用户token>`
- **请求参数**：
  - `status`：可选，订单状态（1待付款 2待接单 3已接单 4派送中 5已完成 6已取消）
- **示例请求**：`GET /user/purchase-history?status=5`
- **响应示例**：
```json
{
  "code": 1,
  "msg": "成功",
  "data": [
    {
      "id": 1,
      "userId": 1,
      "orderId": 1001,
      "dishId": 101,
      "setmealId": null,
      "type": 1,
      "number": 2,
      "orderTime": "2025-12-24 12:00:00",
      "status": 5,
      "name": "宫保鸡丁",
      "image": "http://example.com/dish.jpg",
      "amount": 30.00,
      "orderNumber": "1234567890"
    },
    {
      "id": 2,
      "userId": 1,
      "orderId": 1001,
      "dishId": null,
      "setmealId": 201,
      "type": 2,
      "number": 1,
      "orderTime": "2025-12-24 12:00:00",
      "status": 5,
      "name": "豪华套餐",
      "image": "http://example.com/setmeal.jpg",
      "amount": 70.00,
      "orderNumber": "1234567890"
    }
  ]
}
```

## 3. 取消订单接口
- **接口**：`PUT /user/order/cancel/{id}`
- **请求头**：`Authorization: Bearer <用户token>`
- **路径参数**：`id=1001`
- **响应示例**：
```json
{
  "code": 1,
  "msg": "成功",
  "data": null
}
```

## 4. 验证购买历史状态更新
- **接口**：`GET /user/purchase-history?status=6`
- **请求头**：`Authorization: Bearer <用户token>`
- **响应示例**：
```json
{
  "code": 1,
  "msg": "成功",
  "data": [
    {
      "id": 1,
      "userId": 1,
      "orderId": 1001,
      "dishId": 101,
      "setmealId": null,
      "type": 1,
      "number": 2,
      "orderTime": "2025-12-24 12:00:00",
      "status": 6,
      "name": "宫保鸡丁",
      "image": "http://example.com/dish.jpg",
      "amount": 30.00,
      "orderNumber": "1234567890"
    },
    {
      "id": 2,
      "userId": 1,
      "orderId": 1001,
      "dishId": null,
      "setmealId": 201,
      "type": 2,
      "number": 1,
      "orderTime": "2025-12-24 12:00:00",
      "status": 6,
      "name": "豪华套餐",
      "image": "http://example.com/setmeal.jpg",
      "amount": 70.00,
      "orderNumber": "1234567890"
    }
  ]
}
```