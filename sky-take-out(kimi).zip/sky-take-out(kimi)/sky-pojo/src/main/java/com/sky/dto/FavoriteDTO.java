package com.sky.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 收藏DTO
 */
@Data
public class FavoriteDTO implements Serializable {

    //用户id
    private Long userId;

    //菜品id
    private Long dishId;

    //套餐id
    private Long setmealId;
}