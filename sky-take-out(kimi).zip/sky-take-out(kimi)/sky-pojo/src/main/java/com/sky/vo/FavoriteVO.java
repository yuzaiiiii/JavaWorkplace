package com.sky.vo;

import com.sky.entity.Dish;
import com.sky.entity.Setmeal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 收藏VO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FavoriteVO implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    //用户id
    private Long userId;

    //菜品信息
    private Dish dish;

    //套餐信息
    private Setmeal setmeal;

    //收藏时间
    private LocalDateTime createTime;
}