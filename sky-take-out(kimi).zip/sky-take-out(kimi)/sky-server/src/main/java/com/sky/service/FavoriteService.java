package com.sky.service;

import com.sky.dto.FavoriteDTO;
import com.sky.vo.FavoriteVO;

import java.util.List;

public interface FavoriteService {

    /**
     * 添加收藏
     * @param favoriteDTO
     */
    void add(FavoriteDTO favoriteDTO);

    /**
     * 取消收藏
     * @param favoriteDTO
     */
    void delete(FavoriteDTO favoriteDTO);

    /**
     * 查询用户收藏列表
     * @return
     */
    List<FavoriteVO> list();

    /**
     * 检查是否已收藏
     * @param dishId
     * @param setmealId
     * @return
     */
    boolean check(Long dishId, Long setmealId);
}