package com.sky.controller.user;

import com.sky.dto.FavoriteDTO;
import com.sky.result.Result;
import com.sky.service.FavoriteService;
import com.sky.vo.FavoriteVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 收藏相关接口
 */
@RestController("userFavoriteController")
@RequestMapping("/user/favorite")
@Slf4j
@Api(tags = "C端-收藏相关接口")
public class FavoriteController {

    @Autowired
    private FavoriteService favoriteService;

    /**
     * 添加收藏
     *
     * @param favoriteDTO
     * @return
     */
    @PostMapping
    @ApiOperation("添加收藏")
    public Result<String> add(@RequestBody FavoriteDTO favoriteDTO) {
        log.info("添加收藏：{}", favoriteDTO);
        favoriteService.add(favoriteDTO);
        return Result.success();
    }

    /**
     * 取消收藏
     *
     * @param favoriteDTO
     * @return
     */
    @DeleteMapping
    @ApiOperation("取消收藏")
    public Result<String> delete(@RequestBody FavoriteDTO favoriteDTO) {
        log.info("取消收藏：{}", favoriteDTO);
        favoriteService.delete(favoriteDTO);
        return Result.success();
    }

    /**
     * 查询用户收藏列表
     *
     * @return
     */
    @GetMapping("/list")
    @ApiOperation("查询用户收藏列表")
    public Result<List<FavoriteVO>> list() {
        log.info("查询用户收藏列表");
        List<FavoriteVO> list = favoriteService.list();
        return Result.success(list);
    }

    /**
     * 检查是否已收藏
     *
     * @param dishId
     * @param setmealId
     * @return
     */
    @GetMapping("/check")
    @ApiOperation("检查是否已收藏")
    public Result<Boolean> check(@RequestParam(required = false) Long dishId,
                                @RequestParam(required = false) Long setmealId) {
        log.info("检查是否已收藏，dishId：{}，setmealId：{}", dishId, setmealId);
        boolean isFavorited = favoriteService.check(dishId, setmealId);
        return Result.success(isFavorited);
    }
}