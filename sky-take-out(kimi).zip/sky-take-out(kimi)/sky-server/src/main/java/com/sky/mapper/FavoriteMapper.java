package com.sky.mapper;

import com.sky.entity.Favorite;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface FavoriteMapper {

    /**
     * 插入收藏记录
     * @param favorite
     */
    void insert(Favorite favorite);

    /**
     * 根据用户id和菜品id或套餐id删除收藏记录
     * @param userId
     * @param dishId
     * @param setmealId
     */
    void deleteByUserIdAndDishIdOrSetmealId(Long userId, Long dishId, Long setmealId);

    /**
     * 根据用户id查询收藏列表
     * @param userId
     * @return
     */
    List<Favorite> listByUserId(Long userId);

    /**
     * 根据用户id和菜品id或套餐id统计收藏数量
     * @param userId
     * @param dishId
     * @param setmealId
     * @return
     */
    int countByUserIdAndDishIdOrSetmealId(Long userId, Long dishId, Long setmealId);

    /**
     * 根据用户id和菜品id统计收藏数量
     * @param userId
     * @param dishId
     * @return
     */
    @Select("select count(*) from favorite where user_id = #{userId} and dish_id = #{dishId}")
    int countByUserIdAndDishId(Long userId, Long dishId);

    /**
     * 根据用户id和套餐id统计收藏数量
     * @param userId
     * @param setmealId
     * @return
     */
    @Select("select count(*) from favorite where user_id = #{userId} and setmeal_id = #{setmealId}")
    int countByUserIdAndSetmealId(Long userId, Long setmealId);
}