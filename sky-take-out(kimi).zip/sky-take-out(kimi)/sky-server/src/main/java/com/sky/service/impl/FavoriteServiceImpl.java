package com.sky.service.impl;

import com.sky.context.BaseContext;
import com.sky.dto.FavoriteDTO;
import com.sky.entity.Favorite;
import com.sky.mapper.DishMapper;
import com.sky.mapper.FavoriteMapper;
import com.sky.mapper.SetmealMapper;
import com.sky.service.FavoriteService;
import com.sky.vo.FavoriteVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class FavoriteServiceImpl implements FavoriteService {

    @Autowired
    private FavoriteMapper favoriteMapper;

    @Autowired
    private DishMapper dishMapper;

    @Autowired
    private SetmealMapper setmealMapper;

    /**
     * 添加收藏
     *
     * @param favoriteDTO
     */
    @Override
    public void add(FavoriteDTO favoriteDTO) {
        Long userId = BaseContext.getCurrentId();
        
        // 检查是否已经收藏
        if (check(favoriteDTO.getDishId(), favoriteDTO.getSetmealId())) {
            log.info("该菜品或套餐已被用户收藏，userId：{}，dishId：{}，setmealId：{}", 
                    userId, favoriteDTO.getDishId(), favoriteDTO.getSetmealId());
            return;
        }

        Favorite favorite = new Favorite();
        BeanUtils.copyProperties(favoriteDTO, favorite);
        favorite.setUserId(userId);
        favorite.setCreateTime(LocalDateTime.now());

        favoriteMapper.insert(favorite);
    }

    /**
     * 取消收藏
     *
     * @param favoriteDTO
     */
    @Override
    public void delete(FavoriteDTO favoriteDTO) {
        Long userId = BaseContext.getCurrentId();
        favoriteMapper.deleteByUserIdAndDishIdOrSetmealId(userId, favoriteDTO.getDishId(), favoriteDTO.getSetmealId());
    }

    /**
     * 查询用户收藏列表
     *
     * @return
     */
    @Override
    public List<FavoriteVO> list() {
        Long userId = BaseContext.getCurrentId();
        List<Favorite> favorites = favoriteMapper.listByUserId(userId);

        return favorites.stream().map(favorite -> {
            FavoriteVO favoriteVO = new FavoriteVO();
            BeanUtils.copyProperties(favorite, favoriteVO);

            if (favorite.getDishId() != null) {
                favoriteVO.setDish(dishMapper.getById(favorite.getDishId()));
            }
            if (favorite.getSetmealId() != null) {
                favoriteVO.setSetmeal(setmealMapper.getById(favorite.getSetmealId()));
            }

            return favoriteVO;
        }).collect(Collectors.toList());
    }

    /**
     * 检查是否已收藏
     *
     * @param dishId
     * @param setmealId
     * @return
     */
    @Override
    public boolean check(Long dishId, Long setmealId) {
        Long userId = BaseContext.getCurrentId();
        return favoriteMapper.countByUserIdAndDishIdOrSetmealId(userId, dishId, setmealId) > 0;
    }
}