CREATE TABLE user_purchase_history (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '主键ID',
    user_id BIGINT NOT NULL COMMENT '用户ID',
    order_id BIGINT NOT NULL COMMENT '订单ID',
    goods_id BIGINT NOT NULL COMMENT '商品ID（菜品ID或套餐ID）',
    goods_type INT NOT NULL COMMENT '商品类型 1菜品 2套餐',
    goods_name VARCHAR(100) NOT NULL COMMENT '商品名称',
    goods_image VARCHAR(255) COMMENT '商品图片',
    quantity INT NOT NULL COMMENT '购买数量',
    price DECIMAL(10, 2) NOT NULL COMMENT '商品单价',
    order_time DATETIME NOT NULL COMMENT '下单时间',
    order_status INT NOT NULL COMMENT '订单状态 1待付款 2待接单 3已接单 4派送中 5已完成 6已取消',
    pay_status INT NOT NULL COMMENT '支付状态 0未支付 1已支付 2退款',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_user_id (user_id),
    INDEX idx_order_id (order_id),
    INDEX idx_order_time (order_time)
) COMMENT '用户购买历史表' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;