package com.sky.mapper;

import com.sky.entity.UserPurchaseHistory;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * 用户购买历史Mapper
 */
@Mapper
public interface UserPurchaseHistoryMapper {

    /**
     * 批量插入用户购买历史
     * @param userPurchaseHistoryList
     */
    void insertBatch(List<UserPurchaseHistory> userPurchaseHistoryList);

    /**
     * 根据用户id查询购买历史
     * @param userId
     * @return
     */
    List<UserPurchaseHistory> listByUserId(Long userId);

    /**
     * 根据用户id和订单状态查询购买历史
     * @param userId
     * @param orderStatus
     * @return
     */
    List<UserPurchaseHistory> listByUserIdAndStatus(Long userId, Integer orderStatus);

    /**
     * 根据订单id更新购买历史的订单状态
     * @param orderId
     * @param orderStatus
     */
    void updateOrderStatusByOrderId(Long orderId, Integer orderStatus);

    /**
     * 根据订单id查询购买历史
     * @param orderId
     * @return
     */
    List<UserPurchaseHistory> listByOrderId(Long orderId);
}