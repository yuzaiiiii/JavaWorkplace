package com.sky.controller.user;

import com.sky.context.BaseContext;
import com.sky.entity.UserPurchaseHistory;
import com.sky.result.Result;
import com.sky.service.UserPurchaseHistoryService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 用户购买历史Controller
 */
@RestController("userUserPurchaseHistoryController")
@RequestMapping("/user/purchase/history")
@Api(tags = "C端-用户购买历史接口")
@Slf4j
public class UserPurchaseHistoryController {

    @Autowired
    private UserPurchaseHistoryService userPurchaseHistoryService;

    /**
     * 查询用户购买历史
     * @return
     */
    @GetMapping("/list")
    @ApiOperation("查询用户购买历史")
    public Result<List<UserPurchaseHistory>> list() {
        Long userId = BaseContext.getCurrentId();
        List<UserPurchaseHistory> purchaseHistoryList = userPurchaseHistoryService.listByUserId(userId);
        return Result.success(purchaseHistoryList);
    }

    /**
     * 根据订单状态查询用户购买历史
     * @param orderStatus
     * @return
     */
    @GetMapping("/list/status/{orderStatus}")
    @ApiOperation("根据订单状态查询用户购买历史")
    public Result<List<UserPurchaseHistory>> listByStatus(@PathVariable Integer orderStatus) {
        Long userId = BaseContext.getCurrentId();
        List<UserPurchaseHistory> purchaseHistoryList = userPurchaseHistoryService.listByUserIdAndStatus(userId, orderStatus);
        return Result.success(purchaseHistoryList);
    }

    /**
     * 根据订单id查询购买历史
     * @param orderId
     * @return
     */
    @GetMapping("/list/order/{orderId}")
    @ApiOperation("根据订单id查询购买历史")
    public Result<List<UserPurchaseHistory>> listByOrderId(@PathVariable Long orderId) {
        List<UserPurchaseHistory> purchaseHistoryList = userPurchaseHistoryService.listByOrderId(orderId);
        return Result.success(purchaseHistoryList);
    }
}