package com.sky.service.impl;

import com.sky.entity.UserPurchaseHistory;
import com.sky.mapper.UserPurchaseHistoryMapper;
import com.sky.service.UserPurchaseHistoryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 用户购买历史Service实现类
 */
@Service
@Slf4j
public class UserPurchaseHistoryServiceImpl implements UserPurchaseHistoryService {

    @Autowired
    private UserPurchaseHistoryMapper userPurchaseHistoryMapper;

    /**
     * 批量保存用户购买历史
     * @param userPurchaseHistoryList
     */
    @Override
    public void saveBatch(List<UserPurchaseHistory> userPurchaseHistoryList) {
        if (userPurchaseHistoryList != null && !userPurchaseHistoryList.isEmpty()) {
            userPurchaseHistoryMapper.insertBatch(userPurchaseHistoryList);
            log.info("批量保存用户购买历史成功，共{}条记录", userPurchaseHistoryList.size());
        }
    }

    /**
     * 根据用户id查询购买历史
     * @param userId
     * @return
     */
    @Override
    public List<UserPurchaseHistory> listByUserId(Long userId) {
        return userPurchaseHistoryMapper.listByUserId(userId);
    }

    /**
     * 根据用户id和订单状态查询购买历史
     * @param userId
     * @param orderStatus
     * @return
     */
    @Override
    public List<UserPurchaseHistory> listByUserIdAndStatus(Long userId, Integer orderStatus) {
        return userPurchaseHistoryMapper.listByUserIdAndStatus(userId, orderStatus);
    }

    /**
     * 根据订单id更新购买历史的订单状态
     * @param orderId
     * @param orderStatus
     */
    @Override
    public void updateOrderStatusByOrderId(Long orderId, Integer orderStatus) {
        userPurchaseHistoryMapper.updateOrderStatusByOrderId(orderId, orderStatus);
        log.info("根据订单id更新购买历史的订单状态成功，订单id：{}，新状态：{}", orderId, orderStatus);
    }

    /**
     * 根据订单id查询购买历史
     * @param orderId
     * @return
     */
    @Override
    public List<UserPurchaseHistory> listByOrderId(Long orderId) {
        return userPurchaseHistoryMapper.listByOrderId(orderId);
    }
}