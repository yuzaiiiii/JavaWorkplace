package com.sky.service;

import com.sky.entity.UserPurchaseHistory;
import com.sky.result.PageResult;

import java.util.List;

/**
 * 用户购买历史Service
 */
public interface UserPurchaseHistoryService {

    /**
     * 批量保存用户购买历史
     * @param userPurchaseHistoryList
     */
    void saveBatch(List<UserPurchaseHistory> userPurchaseHistoryList);

    /**
     * 根据用户id查询购买历史
     * @param userId
     * @return
     */
    List<UserPurchaseHistory> listByUserId(Long userId);

    /**
     * 根据用户id和订单状态查询购买历史
     * @param userId
     * @param orderStatus
     * @return
     */
    List<UserPurchaseHistory> listByUserIdAndStatus(Long userId, Integer orderStatus);

    /**
     * 根据订单id更新购买历史的订单状态
     * @param orderId
     * @param orderStatus
     */
    void updateOrderStatusByOrderId(Long orderId, Integer orderStatus);

    /**
     * 根据订单id查询购买历史
     * @param orderId
     * @return
     */
    List<UserPurchaseHistory> listByOrderId(Long orderId);
}