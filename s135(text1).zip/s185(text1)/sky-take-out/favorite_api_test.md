# 收藏功能接口测试数据

## 1. 添加收藏接口

### 接口信息
- **URL**: `POST /user/favorite`
- **请求方法**: POST
- **请求头**: 需要携带JWT token

### 请求示例

#### 收藏菜品
```json
{
  "dishId": 1,
  "setmealId": null
}
```

#### 收藏套餐
```json
{
  "dishId": null,
  "setmealId": 1
}
```

### 响应示例
```json
{
  "code": 1,
  "msg": "成功",
  "data": null
}
```

## 2. 取消收藏接口

### 接口信息
- **URL**: `DELETE /user/favorite`
- **请求方法**: DELETE
- **请求头**: 需要携带JWT token

### 请求示例

#### 取消收藏菜品
```
DELETE /user/favorite?dishId=1
```

#### 取消收藏套餐
```
DELETE /user/favorite?setmealId=1
```

### 响应示例
```json
{
  "code": 1,
  "msg": "成功",
  "data": null
}
```

## 3. 查询收藏列表接口

### 接口信息
- **URL**: `GET /user/favorite/list`
- **请求方法**: GET
- **请求头**: 需要携带JWT token

### 响应示例
```json
{
  "code": 1,
  "msg": "成功",
  "data": [
    {
      "id": 1,
      "userId": 1,
      "dishId": 1,
      "setmealId": null,
      "createTime": "2025-12-24T12:00:00"
    },
    {
      "id": 2,
      "userId": 1,
      "dishId": null,
      "setmealId": 1,
      "createTime": "2025-12-24T12:01:00"
    }
  ]
}
```

## 4. 判断是否已收藏接口

### 接口信息
- **URL**: `GET /user/favorite/isFavorite`
- **请求方法**: GET
- **请求头**: 需要携带JWT token

### 请求示例

#### 判断菜品是否已收藏
```
GET /user/favorite/isFavorite?dishId=1
```

#### 判断套餐是否已收藏
```
GET /user/favorite/isFavorite?setmealId=1
```

### 响应示例

#### 已收藏
```json
{
  "code": 1,
  "msg": "成功",
  "data": true
}
```

#### 未收藏
```json
{
  "code": 1,
  "msg": "成功",
  "data": false
}
```

## 注意事项

1. 所有接口都需要携带有效的JWT token，否则会返回未登录错误
2. 收藏菜品和套餐时，需要确保对应的菜品或套餐存在
3. 取消收藏时，需要确保对应的收藏记录存在
4. 查询收藏列表时，会返回当前登录用户的所有收藏记录
5. 判断是否已收藏时，会返回对应的布尔值