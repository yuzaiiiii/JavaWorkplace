# 收藏功能实现总结

## 一、功能概述

为外卖小程序系统实现了用户收藏菜品或套餐的功能，包括以下核心功能：
1. 用户可以在菜品展示页面中看到每个菜品或套餐后都有一个收藏选项，可以点击
2. 建立了一张新的数据库表名为收藏表，用于存储对应用户收藏的菜品
3. 在菜品展示的页面中添加一个收藏的菜品，用于展示用户收藏过的菜品
4. 当用户点击对应菜品或套餐的收藏选项后，会将此菜品的信息存入新建的收藏表
5. 当用户处于菜品展示页面中时，点击收藏的菜品会展示对应的菜品

## 二、技术实现

### 1. 数据库表设计

创建了名为`favorite`的数据库表，表结构如下：

```sql
CREATE TABLE `favorite` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` bigint NOT NULL COMMENT '用户id',
  `dish_id` bigint DEFAULT NULL COMMENT '菜品id',
  `setmeal_id` bigint DEFAULT NULL COMMENT '套餐id',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_user_dish` (`user_id`,`dish_id`),
  UNIQUE KEY `idx_user_setmeal` (`user_id`,`setmeal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户收藏表';
```

### 2. 后端代码实现

#### 实体类（Favorite.java）
```java
package com.sky.entity;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class Favorite {
    private Long id;
    private Long userId;
    private Long dishId;
    private Long setmealId;
    private LocalDateTime createTime;
}
```

#### Mapper接口（FavoriteMapper.java）
```java
package com.sky.mapper;

import com.sky.entity.Favorite;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface FavoriteMapper {
    void insert(Favorite favorite);
    void delete(@Param("userId") Long userId, @Param("dishId") Long dishId, @Param("setmealId") Long setmealId);
    List<Favorite> listByUserId(Long userId);
    Favorite getByUserIdAndDishIdOrSetmealId(@Param("userId") Long userId, @Param("dishId") Long dishId, @Param("setmealId") Long setmealId);
}
```

#### Mapper XML（FavoriteMapper.xml）
```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN" "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.sky.mapper.FavoriteMapper">

    <insert id="insert">
        insert into favorite (user_id, dish_id, setmeal_id, create_time)
        values (#{userId}, #{dishId}, #{setmealId}, #{createTime})
    </insert>

    <delete id="delete">
        delete from favorite
        where user_id = #{userId}
        <if test="dishId != null">
            and dish_id = #{dishId}
        </if>
        <if test="setmealId != null">
            and setmeal_id = #{setmealId}
        </if>
    </delete>

    <select id="listByUserId" resultType="com.sky.entity.Favorite">
        select * from favorite
        where user_id = #{userId}
        order by create_time desc
    </select>

    <select id="getByUserIdAndDishIdOrSetmealId" resultType="com.sky.entity.Favorite">
        select * from favorite
        where user_id = #{userId}
        <if test="dishId != null">
            and dish_id = #{dishId}
        </if>
        <if test="setmealId != null">
            and setmeal_id = #{setmealId}
        </if>
        limit 1
    </select>

</mapper>
```

#### Service接口（FavoriteService.java）
```java
package com.sky.service;

import com.sky.entity.Favorite;

import java.util.List;

public interface FavoriteService {
    void addFavorite(Long dishId, Long setmealId);
    void cancelFavorite(Long dishId, Long setmealId);
    List<Favorite> listFavorite();
    boolean isFavorite(Long dishId, Long setmealId);
}
```

#### Service实现类（FavoriteServiceImpl.java）
```java
package com.sky.service.impl;

import com.sky.context.BaseContext;
import com.sky.entity.Favorite;
import com.sky.mapper.FavoriteMapper;
import com.sky.service.FavoriteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class FavoriteServiceImpl implements FavoriteService {

    @Autowired
    private FavoriteMapper favoriteMapper;

    @Override
    public void addFavorite(Long dishId, Long setmealId) {
        Long userId = BaseContext.getCurrentId();

        // 检查是否已收藏
        Favorite existing = favoriteMapper.getByUserIdAndDishIdOrSetmealId(userId, dishId, setmealId);
        if (existing != null) {
            return;
        }

        Favorite favorite = new Favorite();
        favorite.setUserId(userId);
        favorite.setDishId(dishId);
        favorite.setSetmealId(setmealId);
        favorite.setCreateTime(LocalDateTime.now());

        favoriteMapper.insert(favorite);
    }

    @Override
    public void cancelFavorite(Long dishId, Long setmealId) {
        Long userId = BaseContext.getCurrentId();
        favoriteMapper.delete(userId, dishId, setmealId);
    }

    @Override
    public List<Favorite> listFavorite() {
        Long userId = BaseContext.getCurrentId();
        return favoriteMapper.listByUserId(userId);
    }

    @Override
    public boolean isFavorite(Long dishId, Long setmealId) {
        Long userId = BaseContext.getCurrentId();
        Favorite favorite = favoriteMapper.getByUserIdAndDishIdOrSetmealId(userId, dishId, setmealId);
        return favorite != null;
    }
}
```

#### Controller（FavoriteController.java）
```java
package com.sky.controller.user;

import com.sky.entity.Favorite;
import com.sky.result.Result;
import com.sky.service.FavoriteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user/favorite")
@CrossOrigin
public class FavoriteController {

    @Autowired
    private FavoriteService favoriteService;

    // 添加收藏
    @PostMapping
    public Result addFavorite(@RequestBody Favorite favorite) {
        favoriteService.addFavorite(favorite.getDishId(), favorite.getSetmealId());
        return Result.success();
    }

    // 取消收藏
    @DeleteMapping
    public Result cancelFavorite(@RequestParam(required = false) Long dishId, @RequestParam(required = false) Long setmealId) {
        favoriteService.cancelFavorite(dishId, setmealId);
        return Result.success();
    }

    // 查询用户收藏的菜品和套餐
    @GetMapping("/list")
    public Result<List<Favorite>> listFavorite() {
        List<Favorite> favorites = favoriteService.listFavorite();
        return Result.success(favorites);
    }

    // 判断是否已收藏
    @GetMapping("/isFavorite")
    public Result<Boolean> isFavorite(@RequestParam(required = false) Long dishId, @RequestParam(required = false) Long setmealId) {
        boolean isFavorite = favoriteService.isFavorite(dishId, setmealId);
        return Result.success(isFavorite);
    }
}
```

## 三、接口测试数据

### 1. 添加收藏接口
- **URL**: `POST /user/favorite`
- **请求方法**: POST
- **请求头**: 需要携带JWT token

**请求示例（收藏菜品）**:
```json
{
  "dishId": 1,
  "setmealId": null
}
```

**请求示例（收藏套餐）**:
```json
{
  "dishId": null,
  "setmealId": 1
}
```

**响应示例**:
```json
{
  "code": 1,
  "msg": "成功",
  "data": null
}
```

### 2. 取消收藏接口
- **URL**: `DELETE /user/favorite`
- **请求方法**: DELETE
- **请求头**: 需要携带JWT token

**请求示例（取消收藏菜品）**:
```
DELETE /user/favorite?dishId=1
```

**请求示例（取消收藏套餐）**:
```
DELETE /user/favorite?setmealId=1
```

**响应示例**:
```json
{
  "code": 1,
  "msg": "成功",
  "data": null
}
```

### 3. 查询收藏列表接口
- **URL**: `GET /user/favorite/list`
- **请求方法**: GET
- **请求头**: 需要携带JWT token

**响应示例**:
```json
{
  "code": 1,
  "msg": "成功",
  "data": [
    {
      "id": 1,
      "userId": 1,
      "dishId": 1,
      "setmealId": null,
      "createTime": "2025-12-24T12:00:00"
    },
    {
      "id": 2,
      "userId": 1,
      "dishId": null,
      "setmealId": 1,
      "createTime": "2025-12-24T12:01:00"
    }
  ]
}
```

### 4. 判断是否已收藏接口
- **URL**: `GET /user/favorite/isFavorite`
- **请求方法**: GET
- **请求头**: 需要携带JWT token

**请求示例（判断菜品是否已收藏）**:
```
GET /user/favorite/isFavorite?dishId=1
```

**请求示例（判断套餐是否已收藏）**:
```
GET /user/favorite/isFavorite?setmealId=1
```

**响应示例（已收藏）**:
```json
{
  "code": 1,
  "msg": "成功",
  "data": true
}
```

**响应示例（未收藏）**:
```json
{
  "code": 1,
  "msg": "成功",
  "data": false
}
```

## 四、注意事项

1. 所有接口都需要携带有效的JWT token，否则会返回未登录错误
2. 收藏菜品和套餐时，需要确保对应的菜品或套餐存在
3. 取消收藏时，需要确保对应的收藏记录存在
4. 查询收藏列表时，会返回当前登录用户的所有收藏记录
5. 判断是否已收藏时，会返回对应的布尔值

## 五、功能验证

用户可以按照以下步骤验证收藏功能是否正常工作：
1. 启动后端服务
2. 使用测试工具（如Postman）或前端页面调用各个接口
3. 验证添加收藏、取消收藏、查询收藏列表和判断是否已收藏功能是否正常
4. 查看数据库中的收藏表，确认数据是否正确存储

## 六、项目启动命令

```bash
# 进入项目根目录
cd sky-take-out

# 启动后端服务
mvn spring-boot:run -Dspring-boot.run.profiles=dev
```

后端服务启动后，接口将在`http://localhost:8080`下可用。