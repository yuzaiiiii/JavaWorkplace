package com.sky.service.impl;

import com.sky.context.BaseContext;
import com.sky.entity.Favorite;
import com.sky.mapper.FavoriteMapper;
import com.sky.service.FavoriteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class FavoriteServiceImpl implements FavoriteService {

    @Autowired
    private FavoriteMapper favoriteMapper;

    @Override
    public void addFavorite(Long dishId, Long setmealId) {
        Long userId = BaseContext.getCurrentId();

        // 检查是否已收藏
        Favorite existing = favoriteMapper.getByUserIdAndDishIdOrSetmealId(userId, dishId, setmealId);
        if (existing != null) {
            return;
        }

        Favorite favorite = new Favorite();
        favorite.setUserId(userId);
        favorite.setDishId(dishId);
        favorite.setSetmealId(setmealId);
        favorite.setCreateTime(LocalDateTime.now());

        favoriteMapper.insert(favorite);
    }

    @Override
    public void cancelFavorite(Long dishId, Long setmealId) {
        Long userId = BaseContext.getCurrentId();
        favoriteMapper.delete(userId, dishId, setmealId);
    }

    @Override
    public List<Favorite> listFavorite() {
        Long userId = BaseContext.getCurrentId();
        return favoriteMapper.listByUserId(userId);
    }

    @Override
    public boolean isFavorite(Long dishId, Long setmealId) {
        Long userId = BaseContext.getCurrentId();
        Favorite favorite = favoriteMapper.getByUserIdAndDishIdOrSetmealId(userId, dishId, setmealId);
        return favorite != null;
    }
}