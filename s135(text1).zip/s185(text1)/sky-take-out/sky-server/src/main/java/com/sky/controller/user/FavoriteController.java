package com.sky.controller.user;

import com.sky.entity.Favorite;
import com.sky.result.Result;
import com.sky.service.FavoriteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user/favorite")
@CrossOrigin
public class FavoriteController {

    @Autowired
    private FavoriteService favoriteService;

    // 添加收藏
    @PostMapping
    public Result addFavorite(@RequestBody Favorite favorite) {
        favoriteService.addFavorite(favorite.getDishId(), favorite.getSetmealId());
        return Result.success();
    }

    // 取消收藏
    @DeleteMapping
    public Result cancelFavorite(@RequestParam(required = false) Long dishId, @RequestParam(required = false) Long setmealId) {
        favoriteService.cancelFavorite(dishId, setmealId);
        return Result.success();
    }

    // 查询用户收藏的菜品和套餐
    @GetMapping("/list")
    public Result<List<Favorite>> listFavorite() {
        List<Favorite> favorites = favoriteService.listFavorite();
        return Result.success(favorites);
    }

    // 判断是否已收藏
    @GetMapping("/isFavorite")
    public Result<Boolean> isFavorite(@RequestParam(required = false) Long dishId, @RequestParam(required = false) Long setmealId) {
        boolean isFavorite = favoriteService.isFavorite(dishId, setmealId);
        return Result.success(isFavorite);
    }
}