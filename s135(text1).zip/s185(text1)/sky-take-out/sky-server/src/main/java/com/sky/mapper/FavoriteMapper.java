package com.sky.mapper;

import com.sky.entity.Favorite;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface FavoriteMapper {

    // 添加收藏
    void insert(Favorite favorite);

    // 删除收藏
    void delete(@Param("userId") Long userId, @Param("dishId") Long dishId, @Param("setmealId") Long setmealId);

    // 查询用户收藏的菜品和套餐
    List<Favorite> listByUserId(Long userId);

    // 判断是否已收藏
    Favorite getByUserIdAndDishIdOrSetmealId(@Param("userId") Long userId, @Param("dishId") Long dishId, @Param("setmealId") Long setmealId);
}