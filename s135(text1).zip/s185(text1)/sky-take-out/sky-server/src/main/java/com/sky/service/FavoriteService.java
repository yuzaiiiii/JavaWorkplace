package com.sky.service;

import com.sky.entity.Favorite;

import java.util.List;

public interface FavoriteService {

    // 添加收藏
    void addFavorite(Long dishId, Long setmealId);

    // 取消收藏
    void cancelFavorite(Long dishId, Long setmealId);

    // 查询用户收藏的菜品和套餐
    List<Favorite> listFavorite();

    // 判断是否已收藏
    boolean isFavorite(Long dishId, Long setmealId);
}